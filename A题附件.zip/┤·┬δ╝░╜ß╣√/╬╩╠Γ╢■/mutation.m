function newpop=mutation(c,pm)
[px,py]=size(c);
z=rand(px,py);
z(z>pm)=0;
z(z<=pm)=1;
c=c+z;
c(c>1)=0;
newpop=c;
end