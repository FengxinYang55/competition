function newpop=crossover(pop,pc,j)
[px,py]=size(pop);
newpop=pop;
w=px;
for i=1:2:px
    if rand<pc
        w=w+1;
        z=ceil(rand*8);
        if z>7
            z=7;
        end
        for q=1:j
            k=(q-1)*24;
            newpop(w,1+k:8+k)=[pop(i,1+k:z+k),pop(i+1,z+1+k:8+k)];
            newpop(w,9+k:16+k)=[pop(i,9+k:9+z+k),pop(i+1,9+z+1+k:16+k)];
            newpop(w,17+k:24+k)=[pop(i,17+k:17+z+k),pop(i+1,17+z+1+k:24+k)];
        end
    end
end