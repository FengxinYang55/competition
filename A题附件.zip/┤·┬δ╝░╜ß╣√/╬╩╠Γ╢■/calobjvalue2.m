function objvalue=calobjvalue2(pop,a)
[x,y]=size(pop);
for i=1:x
    w=pop(i,:);
    objvalue(i,:)=distance2(w,a);
end
end
