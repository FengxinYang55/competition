function newpop=selection2(pop,fitvalue)
[x,y]=size(pop);
for i=1:50
    w=round(x*rand(1,4));
    w=sort(w);
    if w(1)==0
        w(1)=1;
    end
    q=w(1);
    for j=1:4
        if w(j)==0
            w(j)=1;
        end
        if fitvalue(q)>fitvalue(w(j))
            q=w(j);
        end
    end
    newpop(i,:)=pop(q,:);
end
end
