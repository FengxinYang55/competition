function fitvalue=calfitvalue2(objvalue,data1,data2,nowci,m)
[x,y]=size(objvalue);
[x1,y1]=size(data1);
[x2,y2]=size(data2);
q=nowci;
MAX=sqrt(3*255^2);
for z=1:x
    for n=1:m
        q(22+n,1)= objvalue(z,1+(n-1)*3);
        q(22+n,2)= objvalue(z,2+(n-1)*3);
        q(22+n,3)= objvalue(z,3+(n-1)*3);
    end 
        result1=0;
        for i=1:x1
            flag1=1;
            flag2=sqrt((data1(i,2)-q(flag1,1))^2+(data1(i,3)-q(flag1,2))^2+(data1(i,4)-q(flag1,3))^2);
            for j=1:22+m  %%22����ש��ɫ
                w=sqrt((data1(i,2)-q(j,1))^2+(data1(i,3)-q(j,2))^2+(data1(i,4)-q(j,3))^2);
                if(w<flag2)
                    flag1=j;
                    flag2=w;
                end
            end
            result1=result1+flag2;
        end
        result2=0;
        for i=1:x2
            flag1=1;
            flag2=sqrt((data2(i,2)-q(flag1,1))^2+(data2(i,3)-q(flag1,2))^2+(data2(i,4)-q(flag1,3))^2);
            for j=1:22+m  %%22����ש��ɫ
                w=sqrt((data2(i,2)-q(j,1))^2+(data2(i,3)-q(j,2))^2+(data2(i,4)-q(j,3))^2);
                if(w<flag2)
                    flag1=j;
                    flag2=w;
                end
            end
            result2=result2+flag2;
        end
        fitvalue(z)=(result1+result2)/416;
   
end
