%��ʼ��
function pop = initpop(popsize,length)
pop=round(rand(popsize,length));
end