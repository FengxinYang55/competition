function objvalue=calobjvalue(pop,j)
[px,py]=size(pop);
for i = 1:px
    for w=1:j
        objvalue(i,1+3*(w-1))=2^7*pop(i,1+(w-1)*24)+2^6*pop(i,2+(w-1)*24)+2^5*pop(i,3+(w-1)*24)+2^4*pop(i,4+(w-1)*24)+2^3*pop(i,5+(w-1)*24)+2^2*pop(i,6+(w-1)*24)+2*pop(i,7+(w-1)*24)+pop(i,8+(w-1)*24);
        objvalue(i,2+3*(w-1))=2^7*pop(i,9+(w-1)*24)+2^6*pop(i,10+(w-1)*24)+2^5*pop(i,11+(w-1)*24)+2^4*pop(i,12+(w-1)*24)+2^3*pop(i,13+(w-1)*24)+2^2*pop(i,14+(w-1)*24)+2*pop(i,15+(w-1)*24)+pop(i,16+(w-1)*24);
        objvalue(i,3+3*(w-1))=2^7*pop(i,17+(w-1)*24)+2^6*pop(i,18+(w-1)*24)+2^5*pop(i,19+(w-1)*24)+2^4*pop(i,20+(w-1)*24)+2^3*pop(i,21+(w-1)*24)+2^2*pop(i,22+(w-1)*24)+2*pop(i,23+(w-1)*24)+pop(i,24+(w-1)*24);
    end
end
end
